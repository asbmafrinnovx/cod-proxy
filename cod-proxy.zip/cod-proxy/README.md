# COD Proxy — Shopify

Proxy serverless pour créer des commandes Shopify via Admin API.

## Déploiement Vercel

1. Importe ce repo dans Vercel
2. Ajoute la variable d'environnement : `SHOPIFY_ADMIN_TOKEN=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`
3. Déploie
